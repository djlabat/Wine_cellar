import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'wc-wine', // app-wine
  templateUrl: './wine.component.html',
  styleUrls: ['./wine.component.css']
})
export class WineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
